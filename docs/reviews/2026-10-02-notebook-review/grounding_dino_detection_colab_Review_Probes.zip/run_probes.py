"""Probes for the Notebook Review Framework v1 review of tutorials/grounding_dino_detection_colab.ipynb (row 32).

Usage: python run_probes.py <repo_worktree> <weights_root> <out_dir> [--skip-model]

<weights_root> holds a pre-staged `grounding-dino-tiny/` snapshot (with dimer-base-manifest.json) and a `bccd/` photo
cache. The photo cache is copied into <out_dir> first so nothing outside <out_dir> is written. CPU only.

P0 static: tools/build_notebook.py --check and tools/validate_release_assets.py exit codes.
P1 data stage: exec the three carried module cells of the notebook, then the Section 4 data logic (cell 13, default
   path) against the cached photographs; record split sizes, digests and the four refusal probes.
P2 BYOD minimum: synthetic zips of n distinct images through load_byod_dataset -> split_dataset -> per-split
   validate_dataset exactly as cell 13 does; record accepted / rejection message per n. Also a zip whose two images
   share a basename in different folders.
P3 rerun semantics (real pinned model, CPU, tiny subsets): adapt() twice on the same pipe, as a learner re-running
   Section 7 for an optional experiment would; record whether the second call's epoch-0 "frozen model" entry is the
   frozen model or the already-adapted one, and whether a Section 6 re-run would score the adapted model as "frozen".
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WEIGHTS_ROOT = Path(sys.argv[2]).resolve()
OUT = Path(sys.argv[3]).resolve()
SKIP_MODEL = "--skip-model" in sys.argv
OUT.mkdir(parents=True, exist_ok=True)
NB = REPO / "tutorials" / "grounding_dino_detection_colab.ipynb"
results: dict = {"repo": str(REPO), "python": sys.version.split()[0]}


def save() -> None:
    (OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------------------------------------------------------------- P0
p0 = {}
for name, cmd in {"build_check": [sys.executable, "tools/build_notebook.py", "--check"],
                  "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"]}.items():
    proc = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True)
    p0[name] = {"exit": proc.returncode, "tail": (proc.stdout + proc.stderr).strip()[-300:]}
results["P0_static"] = p0
save()

# ---------------------------------------------------------------- P1
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
ns: dict = {"__name__": "__main__"}
os.chdir(OUT)  # the carried module resolves weights/ relative to the working directory
for idx in (5, 7, 9):
    exec(compile("".join(cells[idx]["source"]), f"cell{idx}", "exec"), ns)
cache = OUT / "weights" / "bccd"
if not cache.exists():
    shutil.copytree(WEIGHTS_ROOT / "bccd", cache)
t0 = time.perf_counter()
corpus_files = ns["fetch_corpus"](cache_dir=str(cache))
corpus = ns["read_corpus"](corpus_files)
splits = ns["build_sample_dataset"](corpus, seed=42)
vocabulary = list(ns["PROMPTS"])
manifests = {k: ns["validate_dataset"](v, vocabulary) for k, v in splits.items()}
splits = {k: m["records"] for k, m in manifests.items()}
disjoint = ns["check_split_disjoint"](splits)
train = splits["train"]
probes = {
    "duplicate id": [{**r, "id": "same"} for r in train[:8]],
    "box outside its image": [{**train[0], "boxes": [[-5.0, 0.0, 20.0, 20.0], *train[0]["boxes"][1:]]}, *train[1:8]],
    "label outside the vocabulary": [{**train[0], "labels": ["stem cell", *train[0]["labels"][1:]]}, *train[1:8]],
    "too small": train[:3],
}
probe_out = {}
for name, probe in probes.items():
    try:
        ns["validate_dataset"](probe, vocabulary)
        probe_out[name] = "accepted"
    except (TypeError, ValueError) as exc:
        probe_out[name] = "rejected: " + str(exc)[:110]
results["P1_data_stage"] = {
    "photographs": len(corpus_files), "boxes": sum(len(r["boxes"]) for r in corpus), "splits": disjoint,
    "digests": {k: m["digest"][:16] for k, m in manifests.items()},
    "label_counts": {k: m["label_counts"] for k, m in manifests.items()},
    "refusal_probes": probe_out, "seconds": round(time.perf_counter() - t0, 1),
}
save()

# ---------------------------------------------------------------- P2
from PIL import Image  # noqa: E402

import random  # noqa: E402


def byod_zip(n: int, path: Path, *, nested_dupe: bool = False) -> Path:
    rng = random.Random(n)
    rows = ["file,x0,y0,x1,y1,phrase"]
    with zipfile.ZipFile(path, "w") as zf:
        for i in range(n):
            img = Image.new("RGB", (64, 48), (rng.randrange(256), rng.randrange(256), rng.randrange(256)))
            img.putpixel((i % 64, 0), (i % 256, 7, 9))
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            name = f"img{i:03d}.png"
            zf.writestr(name, buf.getvalue())
            rows.append(f"{name},4,4,30,30,{'cat' if i % 2 else 'dog'}")
        if nested_dupe:
            other = Image.new("RGB", (64, 48), (1, 2, 3))
            buf = io.BytesIO()
            other.save(buf, format="PNG")
            zf.writestr("b/img000.png", buf.getvalue())
        zf.writestr("boxes.csv", "\n".join(rows))
    return path


def cell13_byod(path: Path) -> dict:
    records, vocab = ns["load_byod_dataset"](path)
    out = {"records_loaded": len(records)}
    try:
        sp = ns["split_dataset"](records, vocab, seed=42)
        out["split_sizes"] = {k: len(v) for k, v in sp.items()}
        for name, part in sp.items():
            ns["validate_dataset"](part, vocab)  # exactly as cell 13: default min_records
        out["verdict"] = "accepted"
    except ValueError as exc:
        out["verdict"] = "rejected: " + str(exc)
    return out


p2 = {}
for n in (8, 12, 20, 37, 38, 49, 50):
    p2[f"n={n}"] = cell13_byod(byod_zip(n, OUT / f"byod_{n}.zip"))
p2["nested_same_basename(n=50 + b/img000.png)"] = cell13_byod(byod_zip(50, OUT / "byod_dupe.zip", nested_dupe=True))
results["P2_byod_minimum"] = p2
save()

# ---------------------------------------------------------------- P3
if not SKIP_MODEL:
    import torch  # noqa: E402

    torch.set_num_threads(8)
    t0 = time.perf_counter()
    pipe = ns["GroundingDINOPipeline"].from_pretrained(weights_dir=WEIGHTS_ROOT / "grounding-dino-tiny", device="cpu")
    load_s = round(time.perf_counter() - t0, 1)
    names = ns["_trainable_names"](pipe._model)

    def decoder_digest() -> str:
        state = pipe._model.state_dict()
        h = hashlib.sha256()
        for k in sorted(names)[:6]:
            h.update(state[k].detach().cpu().numpy().tobytes())
        return h.hexdigest()[:16]

    tr, va = splits["train"][:8], splits["validation"][:2]
    base_digest = decoder_digest()
    base_val = pipe.evaluate(va, vocabulary)["map50"]
    t0 = time.perf_counter()
    r1 = pipe.adapt(tr, va, vocabulary, epochs=1, lr=5e-4, batch_size=4)
    after1_digest = decoder_digest()
    after1_val = pipe.evaluate(va, vocabulary)["map50"]
    r2 = pipe.adapt(tr, va, vocabulary, epochs=1, lr=1e-5, batch_size=4)
    results["P3_rerun_semantics"] = {
        "device": "cpu", "torch": torch.__version__, "load_seconds": load_s,
        "subset": {"train": len(tr), "val": len(va)}, "note": "lr 5e-4 for the first call only to move the weights visibly in one step-pair; the semantics do not depend on it",
        "base_decoder_digest": base_digest, "after_first_adapt_digest": after1_digest,
        "base_val_map50": round(base_val, 4), "after_first_adapt_val_map50": round(after1_val, 4),
        "first_call_epoch0": {"note": r1["history"][0].get("note"), "val_map50": round(r1["history"][0]["val"]["map50"], 4)},
        "second_call_epoch0": {"note": r2["history"][0].get("note"), "val_map50": round(r2["history"][0]["val"]["map50"], 4)},
        "second_call_epoch0_equals_adapted_not_base": round(r2["history"][0]["val"]["map50"], 6) == round(after1_val, 6) and after1_digest != base_digest,
        "section6_rerun_would_score_as_frozen_map50": round(after1_val, 4),
        "seconds": round(time.perf_counter() - t0, 1),
    }
    save()

src = REPO / "src" / "grounding_dino_detection_pipeline"
manifest = {}
for rel in ["tutorials/grounding_dino_detection_colab.ipynb", "tutorials/README.md", "README.md", "STATUS.md",
            "docs/release-verification.md", "tools/build_notebook.py", "tools/notebook_template.py",
            "tools/validate_release_assets.py", "src/grounding_dino_detection_pipeline/pipeline.py",
            "src/grounding_dino_detection_pipeline/metrics.py", "src/grounding_dino_detection_pipeline/samples.py",
            "pyproject.toml"]:
    manifest[rel] = hashlib.sha256((REPO / rel).read_bytes()).hexdigest()
(OUT / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps(results, indent=1, default=str))
